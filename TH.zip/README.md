# 🕵 SELFBOT-BY:MAX 🕵

# Group Self bot
https://line.me/ti/g2/SIGRN7I2Z0

#  🕵  SELFBOT-BY:MAX 🕵 PY3

- `apt update`
- `apt upgrade`
- `apt install python`
- `pip3 install pytz`
- `pip3 install requests`
- `pip3 install rsa`
- `pip3 install bs4`
- `pip3 install gtts` 
- `pip3 install goslate`
- `pip3 install googletrans`
- `pip3 install pafy`
- `pip3 install youtube_dl`
- `pip3 install humanfriendly`
- `pip3 install thrift==0.11.0`
- `pip3 install tweepy`
- `pip3 install wikipedia`
- `apt install git`

#  🕵  SELFBOT-BY:MAX 🕵 PY2

- `pkg install python2 -y`
- `pkg install nano -y`
- `pkg install git -y`
- `pip2 install rsa`
- `pip2 install requests`
- `pip2 install goslate`
- `pip2 install googletrans`
- `pip2 install bs4`
- `pip2 install gtts`
- `pip2 install html5lib`
- `pip2 install wikipedia`
- `pip2 install screen`
- `pkg install python-tz`
- `pip2 install thrift==0.9.3`
- `pip2 install BeautifulSoup`
- `pip2 install BeautifulSoup4`
- `pip2 install html5`
- `pip2 install tweepy`
- `pip2 install pyowm`
- `pip2 install urllib`
- `pip2 install threading`


# install di termux copas satu...
# Untuk git clone nya scroll aj ke atas...
# aq udah share git nya...
